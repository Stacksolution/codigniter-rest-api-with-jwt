
## Porting Progress

### `V.1.1.7`

* Update CodeIgniter `3.1.10`
* Upload Online Library POST Request : `http://codeigniter-api.speedtyping.in/api/user/login`
* Rename `Authorization_token` file

### `V.1.1.6`

* `Fix BUG` in API Limit

### `V.1.1.5`

* If the database library did not load, the error was shown
* change API errors string
* modify documentation